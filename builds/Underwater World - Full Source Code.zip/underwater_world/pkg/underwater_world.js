import * as wasm from "./underwater_world_bg.wasm";
import { __wbg_set_wasm } from "./underwater_world_bg.js";
__wbg_set_wasm(wasm);
export * from "./underwater_world_bg.js";

wasm.__wbindgen_start();
