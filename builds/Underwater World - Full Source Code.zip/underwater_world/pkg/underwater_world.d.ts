/* tslint:disable */
/* eslint-disable */
/**
*/
export function run(): void;
